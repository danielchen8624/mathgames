/* ---------- exact math + solver ---------- */
function shuffle(a){a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));const t=a[i];a[i]=a[j];a[j]=t}return a}
function gcd(a,b){a=Math.abs(a);b=Math.abs(b);while(b){const t=a%b;a=b;b=t}return a}
function fr(n,d){if(d===undefined)d=1;if(d<0){n=-n;d=-d}const g=gcd(n,d)||1;return{n:n/g,d:d/g}}
function fadd(a,b){return fr(a.n*b.d+b.n*a.d,a.d*b.d)}
function fsub(a,b){return fr(a.n*b.d-b.n*a.d,a.d*b.d)}
function fmul(a,b){return fr(a.n*b.n,a.d*b.d)}
function fdiv(a,b){if(b.n===0)throw new Error('div0');return fr(a.n*b.d,a.d*b.n)}

/* Evaluates "13 × (5 − 1) + 2" with normal precedence, exactly. */
function evalExpr(str){
  const toks=str.match(/\d+|[()+−×÷]/g)||[];let p=0;
  function peek(){return toks[p]}
  function expr(){let v=term();while(peek()==='+'||peek()==='−'){const o=toks[p++];const r=term();v=o==='+'?fadd(v,r):fsub(v,r)}return v}
  function term(){let v=factor();while(peek()==='×'||peek()==='÷'){const o=toks[p++];const r=factor();v=o==='×'?fmul(v,r):fdiv(v,r)}return v}
  function factor(){
    const t=toks[p++];
    if(t===undefined)throw new Error('syntax');
    if(t==='('){const v=expr();if(toks[p++]!==')')throw new Error('syntax');return v}
    if(/^\d+$/.test(t))return fr(+t,1);
    throw new Error('syntax');
  }
  const v=expr();if(p!==toks.length)throw new Error('syntax');return v;
}

/* Combine two partial results; p = precedence (1 add/sub, 2 mul/div, 3 atom). */
function combine(op,a,b){
  const w=function(x,need){return need?'('+x.e+')':x.e};
  if(op==='+')return{v:a.v+b.v,e:a.e+' + '+b.e,p:1};
  if(op==='−')return{v:a.v-b.v,e:w(a,false)+' − '+w(b,b.p<=1),p:1};
  if(op==='×')return{v:a.v*b.v,e:w(a,a.p<2)+' × '+w(b,b.p<2),p:2};
  return{v:a.v/b.v,e:w(a,a.p<2)+' ÷ '+w(b,b.p<3),p:2};
}

/* Returns an expression string using every number once that equals target, or null. */
function solve(nums,target){
  const EPS=1e-6,seen=new Set();
  function rec(items){
    const n=items.length;
    if(n===2){
      const a=items[0],b=items[1];
      const tests=[['+',a,b],['×',a,b],['−',a,b],['−',b,a],['÷',a,b],['÷',b,a]];
      for(let k=0;k<tests.length;k++){
        const op=tests[k][0],x=tests[k][1],y=tests[k][2];
        let v;
        if(op==='+')v=x.v+y.v;else if(op==='×')v=x.v*y.v;else if(op==='−')v=x.v-y.v;
        else{if(Math.abs(y.v)<EPS)continue;v=x.v/y.v}
        if(Math.abs(v-target)<EPS)return combine(op,x,y).e;
      }
      return null;
    }
    const key=items.map(function(x){return Math.round(x.v*1e6)}).sort(function(p,q){return p-q}).join(',');
    if(seen.has(key))return null;
    seen.add(key);
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
      const a=items[i],b=items[j];
      const rest=items.filter(function(_,k){return k!==i&&k!==j});
      const c=[combine('+',a,b),combine('×',a,b),combine('−',a,b),combine('−',b,a)];
      if(Math.abs(b.v)>EPS)c.push(combine('÷',a,b));
      if(Math.abs(a.v)>EPS)c.push(combine('÷',b,a));
      for(let k=0;k<c.length;k++){
        const r=rec(rest.concat([c[k]]));
        if(r)return r;
      }
    }
    return null;
  }
  const items=shuffle(nums).map(function(v){return{v:v,e:String(v),p:3}});
  const e=rec(items);
  if(!e)return null;
  /* exact re-check: right value, and each number used exactly once */
  const f=evalExpr(e);
  const used=(e.match(/\d+/g)||[]).map(Number).sort(function(a,b){return a-b}).join(',');
  const want=nums.slice().sort(function(a,b){return a-b}).join(',');
  return(f.d===1&&f.n===target&&used===want)?e:null;
}
if(typeof module!=='undefined')module.exports={solve:solve,evalExpr:evalExpr,shuffle:shuffle};
