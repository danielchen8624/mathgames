# 24 · 73 · 211

A card showdown against the computer. Race it to hit the target using every card once.

## Run it

Unzip the folder and double-click **index.html**. That's it: no install, no server, no build step.

Needs a modern browser (Chrome, Edge, Firefox, Safari). The fonts load from Google Fonts, so
you need internet for the exact look. Offline it falls back to Didot / Georgia and still works.

## The three games

| Game | Target | Cards dealt |
| ---- | ------ | ----------- |
| 24   | 24     | 4           |
| 73   | 73     | 5           |
| 211  | 211    | 6           |

Each round picks one of the three at random. Cards come from a real 52-card deck
(A = 1, J = 11, Q = 12, K = 13). Every deal is checked by a solver first, so a solution
always exists.

## How to play

1. Click a card, then an operation (+ − × ÷), then the next card, and so on. Brackets are allowed.
2. Everything you click shows up on the shelf at the top. You must use every card exactly once.
3. The round ends the moment your line equals the target. The computer is solving too, and
   if it finishes first it takes the round. First to 5 rounds wins the match.

Keyboard: `1`–`6` pick cards, `+ - * / ( )` for operations, `Backspace` undo, `Esc` clear.

Difficulty (Easy / Medium / Hard) sets how fast the computer solves, from the next round on.

## History

The History button lists every round: the cards, the target, who won, your line and a
working solution. It is saved in your browser (localStorage), so it survives reloads, but it
stays in that one browser and is wiped if you clear site data. Opening the page from a
different folder counts as a different site in some browsers, so keep the folder where it is
if you want to keep your history.

## Files

- `index.html` – the page structure
- `style.css` – all the styling (felt table, cards, chips, shelf)
- `solver.js` – exact-fraction expression evaluator and the solver that guarantees every deal is possible
- `game.js` – the game itself (dealing, shelf, computer opponent, scoring, history)
