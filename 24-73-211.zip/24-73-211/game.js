(function(){
'use strict';
var $=function(s,r){return(r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};

var SUITS=[{g:'♠︎',name:'spades',red:false},{g:'♥︎',name:'hearts',red:true},{g:'♦︎',name:'diamonds',red:true},{g:'♣︎',name:'clubs',red:false}];
var RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
var RANK_NAMES=['Ace','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Jack','Queen','King'];
var PIPS={
  2:[[1,0],[1,6]],
  3:[[1,0],[1,3],[1,6]],
  4:[[0,0],[2,0],[0,6],[2,6]],
  5:[[0,0],[2,0],[1,3],[0,6],[2,6]],
  6:[[0,0],[2,0],[0,3],[2,3],[0,6],[2,6]],
  7:[[0,0],[2,0],[1,1.5],[0,3],[2,3],[0,6],[2,6]],
  8:[[0,0],[2,0],[1,1.5],[0,3],[2,3],[1,4.5],[0,6],[2,6]],
  9:[[0,0],[2,0],[0,2],[2,2],[1,3],[0,4],[2,4],[0,6],[2,6]],
  10:[[0,0],[2,0],[1,1],[0,2],[2,2],[0,4],[2,4],[1,5],[0,6],[2,6]]
};
var GOAL=5;
var DIFF={easy:[75,130],medium:[45,85],hard:[25,50]};
var NF={4:0.8,5:1,6:1.25};
var OPCLASS={'+':'c-add','−':'c-sub','×':'c-mul','÷':'c-div'};

var el={
  diff:$('#diff'),rulesBtn:$('#rulesBtn'),rules:$('#rules'),newBtn:$('#newBtn'),histBtn:$('#histBtn'),history:$('#history'),
  youState:$('#youState'),cpuState:$('#cpuState'),youPips:$('#youPips'),cpuPips:$('#cpuPips'),
  youSlots:$('#youSlots'),cpuSlots:$('#cpuSlots'),cpuFill:$('#cpuFill'),
  tLab:$('#tLab'),tNum:$('#tNum'),tMeta:$('#tMeta'),
  readout:$('#readout'),shelf:$('#shelf'),tokens:$('#tokens'),empty:$('#empty'),eq:$('#eq'),
  table:$('#table'),deckCount:$('#deckCount'),stack:$('#stack'),hand:$('#hand'),chips:$('#chips'),
  undo:$('#undo'),clear:$('#clear'),giveup:$('#giveup'),
  result:$('#result'),rEyebrow:$('#rEyebrow'),rTitle:$('#rTitle'),rLab:$('#rLab'),rLine:$('#rLine'),rBtn:$('#rBtn')
};

var S={you:0,cpu:0,round:0,phase:'idle',puzzle:null,tokens:[],used:new Set(),elapsed:0,cpuTime:60000,last:0,timer:0,diff:'medium',userExpr:'',matchId:Date.now()};

try{var saved=localStorage.getItem('t24-73-211-diff');if(saved&&DIFF[saved]){S.diff=saved;el.diff.value=saved}}catch(e){}

function rand(a,b){return a+Math.random()*(b-a)}
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function fmt(f){return f.d===1?String(f.n):f.n+'/'+f.d}
function fmtTime(ms){var s=Math.round(ms/1000);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}

/* ---------- dealing ---------- */
function fullDeck(){var d=[];for(var s=0;s<4;s++)for(var r=0;r<13;r++)d.push({r:r,val:r+1,suit:s});return d}
function makePuzzle(){
  var target=pick([24,73,211]),n={24:4,73:5,211:6}[target];
  for(var tries=0;tries<20000;tries++){
    var cards=shuffle(fullDeck()).slice(0,n);
    var sol=solve(cards.map(function(c){return c.val}),target);
    if(sol)return{target:target,n:n,cards:cards,solution:sol};
  }
  return makePuzzle();
}

/* ---------- expression helpers ---------- */
function openCount(){var o=0;S.tokens.forEach(function(t){if(t.t==='par')o+=t.v==='('?1:-1});return o}
function expecting(){
  var l=S.tokens[S.tokens.length-1];
  if(!l)return'operand';
  return(l.t==='card'||(l.t==='par'&&l.v===')'))?'operator':'operand';
}
function exprString(){
  return S.tokens.map(function(t){
    if(t.t==='card')return String(S.puzzle.cards[t.i].val);
    return t.v;
  }).join(' ').replace(/\( /g,'(').replace(/ \)/g,')');
}
function status(){
  var t=S.tokens;
  if(!t.length)return{k:'none'};
  var last=t[t.length-1];
  var ends=last.t==='card'||(last.t==='par'&&last.v===')');
  if(!ends||openCount()>0)return{k:'partial'};
  try{return{k:'val',v:evalExpr(exprString()),full:S.used.size===S.puzzle.n}}catch(e){return{k:'err'}}
}

/* ---------- rendering ---------- */
function pipsHTML(score){var h='';for(var i=0;i<GOAL;i++)h+='<i class="pip'+(i<score?' on':'')+'"></i>';return h}
function renderScore(){
  el.youPips.innerHTML=pipsHTML(S.you);el.cpuPips.innerHTML=pipsHTML(S.cpu);
  el.youPips.setAttribute('aria-label','You '+S.you);
}
function cardFaceHTML(c){
  var rk=RANKS[c.r],sg=SUITS[c.suit].g;
  var h='<span class="corner"><b>'+rk+'</b><i>'+sg+'</i></span><span class="corner br"><b>'+rk+'</b><i>'+sg+'</i></span>';
  if(c.val===1)h+='<span class="ace">'+sg+'</span>';
  else if(c.val>=11)h+='<span class="court"><b>'+rk+'</b><i>'+sg+'</i><em>'+c.val+'</em></span>';
  else PIPS[c.val].forEach(function(p){h+='<span class="pp'+(p[1]>3?' flip':'')+'" style="--c:'+p[0]+';--r:'+p[1]+'">'+sg+'</span>'});
  return h;
}
function renderPuzzle(){
  var p=S.puzzle;
  el.tLab.textContent='Round '+S.round;
  el.tNum.textContent=p.target;
  el.tMeta.textContent=p.n+' cards · the '+p.target+' game';
  $$('h1 .g').forEach(function(g){g.classList.toggle('on',+g.dataset.g===p.target)});
  el.deckCount.textContent=(52-p.n)+' cards in the deck';
  var y='',c='';for(var i=0;i<p.n;i++){y+='<i class="ms you"></i>';c+='<i class="ms cpu"></i>'}
  el.youSlots.innerHTML=y;el.cpuSlots.innerHTML=c;
}
function renderHand(animate){
  el.hand.innerHTML='';
  S.puzzle.cards.forEach(function(c,i){
    var slot=document.createElement('div');slot.className='slot';
    var b=document.createElement('button');
    b.type='button';b.className='card '+(SUITS[c.suit].red?'red':'black');b.dataset.i=i;
    b.style.setProperty('--rot',rand(-2.2,2.2).toFixed(2)+'deg');
    b.setAttribute('aria-label',RANK_NAMES[c.r]+' of '+SUITS[c.suit].name+', value '+c.val);
    b.innerHTML=cardFaceHTML(c);
    slot.appendChild(b);el.hand.appendChild(slot);
  });
  fitHand();
  if(animate)dealAnim();
}
function dealAnim(){
  var d=el.stack.getBoundingClientRect(),dx=d.left+d.width/2,dy=d.top+d.height/2;
  $$('.card',el.hand).forEach(function(b,k){
    var r=b.getBoundingClientRect();
    b.style.setProperty('--fx',(dx-(r.left+r.width/2))+'px');
    b.style.setProperty('--fy',(dy-(r.top+r.height/2))+'px');
    b.style.animationDelay=(k*90)+'ms';
    b.classList.add('deal');
    b.addEventListener('animationend',function(){b.classList.remove('deal');b.style.animationDelay=''},{once:true});
  });
}
var lastW=0;
function fitHand(){
  if(!S.puzzle)return;
  var n=S.puzzle.n,gap=n>=6?8:12,w=el.hand.clientWidth;
  if(!w)return;
  lastW=w;
  var cw=Math.max(40,Math.min(116,Math.floor((w-(n-1)*gap)/n)));
  el.hand.style.setProperty('--cw',cw+'px');
  el.hand.style.setProperty('--gap',gap+'px');
}
if(window.ResizeObserver){new ResizeObserver(function(){if(el.hand.clientWidth!==lastW)fitHand()}).observe(el.hand)}
else window.addEventListener('resize',fitHand);

function renderShelf(animateLast){
  el.tokens.innerHTML='';
  S.tokens.forEach(function(t,idx){
    var n;
    if(t.t==='card'){
      var c=S.puzzle.cards[t.i];
      n=document.createElement('span');n.className='tk ctk'+(SUITS[c.suit].red?' red':'');
      n.innerHTML='<b>'+RANKS[c.r]+'</b><i>'+SUITS[c.suit].g+'</i>';
      n.title=RANK_NAMES[c.r]+' of '+SUITS[c.suit].name+' = '+c.val;
    }else if(t.t==='op'){
      n=document.createElement('span');n.className='tk chip sm '+OPCLASS[t.v];
      n.innerHTML='<span>'+t.v+'</span>';
    }else{
      n=document.createElement('span');n.className='tk ptk';n.textContent=t.v;
    }
    if(animateLast&&idx===S.tokens.length-1)n.classList.add('new');
    el.tokens.appendChild(n);
  });
  var empty=S.tokens.length===0;
  el.empty.hidden=!empty;
  el.empty.textContent=S.phase==='playing'?'Tap a card, then an operation. Your line builds up here.':(S.phase==='dealing'?'Shuffling the deck…':'');
}
function updateControls(){
  var playing=S.phase==='playing',exp=expecting();
  $$('.card',el.hand).forEach(function(b){
    var i=+b.dataset.i,used=S.used.has(i);
    b.classList.toggle('used',used);
    b.disabled=!(playing&&!used&&exp==='operand');
    b.classList.toggle('wait',playing&&!used&&exp==='operator');
  });
  $$('[data-op]',el.chips).forEach(function(b){b.disabled=!(playing&&exp==='operator')});
  $$('[data-par]',el.chips).forEach(function(b){
    b.disabled=b.dataset.par==='('?!(playing&&exp==='operand'):!(playing&&exp==='operator'&&openCount()>0);
  });
  el.undo.disabled=!(playing&&S.tokens.length);
  el.clear.disabled=!(playing&&S.tokens.length);
  el.giveup.disabled=!playing;
  if(S.puzzle)$$('.ms.you',el.youSlots).forEach(function(m,i){m.classList.toggle('on',i<S.used.size)});
}
function updateReadout(){
  var st=status(),left=S.puzzle?S.puzzle.n-S.used.size:0;
  el.readout.className='readout';el.readout.textContent='';
  var txt=exprString();
  el.eq.textContent=txt;
  if(st.k==='partial'){el.readout.textContent='…'}
  else if(st.k==='err'){el.readout.textContent='can’t divide by 0';el.readout.classList.add('bad')}
  else if(st.k==='val'){
    el.readout.textContent='= '+fmt(st.v);
    if(st.full){
      if(!(st.v.d===1&&st.v.n===S.puzzle.target))el.readout.classList.add('bad');
    }else{
      var s=document.createElement('span');s.className='dim';
      s.textContent=' · '+left+(left===1?' card':' cards')+' left to use';
      el.eq.appendChild(s);
    }
  }
}
function refresh(animateLast){
  renderShelf(animateLast);updateControls();updateReadout();
}

/* ---------- player actions ---------- */
function canPlay(){return S.phase==='playing'}
function pickCard(i){
  if(!canPlay()||S.used.has(i)||expecting()!=='operand')return;
  S.tokens.push({t:'card',i:i});S.used.add(i);afterChange();
}
function pickOp(v){
  if(!canPlay()||expecting()!=='operator')return;
  S.tokens.push({t:'op',v:v});afterChange();
}
function pickPar(v){
  if(!canPlay())return;
  var ok=v==='('?expecting()==='operand':(expecting()==='operator'&&openCount()>0);
  if(!ok)return;
  S.tokens.push({t:'par',v:v});afterChange();
}
function afterChange(){
  refresh(true);
  var st=status();
  if(st.k==='val'&&st.full&&st.v.d===1&&st.v.n===S.puzzle.target){
    S.userExpr=exprString();
    el.shelf.classList.add('win');
    endRound('you');
  }
}
function undo(){
  if(!canPlay()||!S.tokens.length)return;
  var t=S.tokens.pop();if(t.t==='card')S.used.delete(t.i);
  refresh(false);
}
function clearAll(){
  if(!canPlay()||!S.tokens.length)return;
  S.tokens=[];S.used=new Set();refresh(false);
}

/* ---------- computer ---------- */
function updateCpu(){
  var p=Math.min(1,S.elapsed/S.cpuTime),n=S.puzzle.n;
  el.cpuFill.style.width=(p*100)+'%';
  var k=Math.floor(p*n);
  $$('.ms.cpu',el.cpuSlots).forEach(function(m,i){m.classList.toggle('on',i<k)});
  el.cpuState.textContent=p<0.25?'Studying the cards…':p<0.6?'Working on it…':p<0.9?'Getting close…':'Almost there!';
}
function tick(){
  var now=performance.now();
  if(!document.hidden)S.elapsed+=Math.min(now-S.last,500);
  S.last=now;
  if(S.phase!=='playing')return;
  updateCpu();
  if(S.elapsed>=S.cpuTime)endRound('cpu');
}

/* ---------- rounds ---------- */
function startRound(){
  clearInterval(S.timer);
  S.round++;S.phase='dealing';S.tokens=[];S.used=new Set();S.userExpr='';
  el.result.hidden=true;el.shelf.classList.remove('win');
  el.hand.innerHTML='';
  el.youState.textContent='Shuffling…';el.cpuState.textContent='Shuffling…';
  el.tLab.textContent='Round '+S.round;el.tNum.textContent='–';el.tMeta.innerHTML='&nbsp;';
  el.cpuFill.style.width='0';el.readout.textContent='';el.eq.textContent='';
  renderScore();renderShelf(false);updateControls();
  setTimeout(function(){
    S.puzzle=makePuzzle();
    var r=DIFF[S.diff];
    S.cpuTime=rand(r[0],r[1])*NF[S.puzzle.n]*1000;
    S.elapsed=0;S.last=performance.now();S.phase='playing';
    renderPuzzle();renderHand(true);
    el.youState.textContent='Your move';updateCpu();
    refresh(false);
    S.timer=setInterval(tick,200);
  },40);
}
function endRound(who){
  if(S.phase!=='playing')return;
  S.phase='over';clearInterval(S.timer);
  if(who==='you')S.you++;else S.cpu++;
  renderScore();updateControls();
  recordRound(who);
  if(who!=='you'){
    $$('.ms.cpu',el.cpuSlots).forEach(function(m){m.classList.add('on')});
    el.cpuFill.style.width='100%';
  }
  el.youState.textContent=who==='you'?'Solved it':(who==='giveup'?'Gave up':'Too slow');
  el.cpuState.textContent=who==='you'?'Still thinking…':'Solved it';
  showResult(who);
}
function showResult(who){
  var p=S.puzzle,over=S.you>=GOAL||S.cpu>=GOAL;
  var eyebrow='Round '+S.round+' · '+fmtTime(S.elapsed)+' · score '+S.you+'–'+S.cpu;
  var title,lab,line;
  el.rTitle.className='';
  if(who==='you'){
    title=over?'You win the match':'You got it';el.rTitle.className='win';
    lab='Your line';line=S.userExpr+' = '+p.target;
  }else if(who==='cpu'){
    title=over?'Computer wins the match':'Computer got there first';
    lab='Computer played';line=p.solution+' = '+p.target;
  }else{
    title=over?'Computer wins the match':'Round conceded';
    lab='One way to do it';line=p.solution+' = '+p.target;
  }
  el.rEyebrow.textContent=eyebrow;el.rTitle.textContent=title;el.rLab.textContent=lab;el.rLine.textContent=line;
  el.rBtn.textContent=over?'New match':'Next round';
  el.result.hidden=false;
  el.rBtn.focus({preventScroll:true});
}
function resetMatch(){S.you=0;S.cpu=0;S.round=0;S.matchId=Date.now();startRound()}

/* ---------- history (kept in this browser) ---------- */
var HKEY='t24-73-211-history';
function cleanExpr(s){return String(s||'').replace(/[^0-9()+−×÷ ]/g,'').slice(0,200)}
function loadHist(){
  try{
    var raw=JSON.parse(localStorage.getItem(HKEY)||'[]');
    if(!Array.isArray(raw))return[];
    return raw.map(function(h){
      var cards=(Array.isArray(h.cards)?h.cards:[]).map(function(c){return{r:+c.r,s:+c.s}}).filter(function(c){return c.r>=0&&c.r<13&&c.s>=0&&c.s<4});
      return{m:+h.m||0,round:+h.round||0,target:+h.target,cards:cards,who:h.who,t:+h.t||0,mine:cleanExpr(h.mine),sol:cleanExpr(h.sol),ts:+h.ts||0};
    }).filter(function(h){return[24,73,211].indexOf(h.target)>=0&&h.cards.length>=4&&['you','cpu','giveup'].indexOf(h.who)>=0});
  }catch(e){return[]}
}
var hist=loadHist();
function saveHist(){try{localStorage.setItem(HKEY,JSON.stringify(hist.slice(-400)))}catch(e){}}
function updateHistBtn(){el.histBtn.textContent='History'+(hist.length?' · '+hist.length:'')}
function fmtDate(ts){try{return new Date(ts).toLocaleString([],{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}catch(e){return''}}
function recordRound(who){
  var p=S.puzzle;
  hist.push({m:S.matchId,round:S.round,target:p.target,cards:p.cards.map(function(c){return{r:c.r,s:c.suit}}),who:who,t:Math.round(S.elapsed),mine:who==='you'?S.userExpr:'',sol:p.solution,ts:Date.now()});
  if(hist.length>400)hist=hist.slice(-400);
  saveHist();updateHistBtn();
  if(!el.history.hidden)renderHist();
}
function renderHist(){
  if(!hist.length){el.history.innerHTML='<div class="hEmpty">No rounds yet. Finish a round and it shows up here with the answer.</div>';return}
  var groups={},order=[],h='';
  hist.forEach(function(r){if(!groups[r.m]){groups[r.m]=[];order.push(r.m)}groups[r.m].push(r)});
  order.sort(function(a,b){return b-a});
  var wins=hist.filter(function(r){return r.who==='you'}).length;
  h+='<div class="hHead"><span class="label">'+hist.length+(hist.length===1?' round':' rounds')+' · you won '+wins+'</span><button class="btn" id="hClear" type="button">Clear history</button></div>';
  order.forEach(function(m){
    var rs=groups[m],you=rs.filter(function(r){return r.who==='you'}).length,cpu=rs.length-you;
    var status=you>=GOAL?'Won':cpu>=GOAL?'Lost':(m===S.matchId?'In progress':'Unfinished');
    h+='<div class="hMatch"><div class="hMatchHead"><b>'+fmtDate(rs[0].ts)+'</b><span>You '+you+'–'+cpu+' Computer · '+status+'</span></div>';
    rs.slice().reverse().forEach(function(r){
      var cards=r.cards.map(function(c){var s=SUITS[c.s];return'<span class="hc'+(s.red?' red':'')+'"><b>'+RANKS[c.r]+'</b><i>'+s.g+'</i></span>'}).join('');
      var who=r.who==='you'?'<span class="pill you">You · '+fmtTime(r.t)+'</span>':'<span class="pill">'+(r.who==='cpu'?'Computer':'Gave up')+' · '+fmtTime(r.t)+'</span>';
      h+='<div class="hRound"><div class="hTop"><span class="hNum">R'+r.round+'</span><span class="hCards">'+cards+'</span><span class="hTarget">→ '+r.target+'</span>'+who+'</div>';
      if(r.mine)h+='<div class="hLine"><span>Your line</span>'+r.mine+' = '+r.target+'</div>';
      h+='<div class="hLine"><span>Solution</span>'+r.sol+' = '+r.target+'</div></div>';
    });
    h+='</div>';
  });
  el.history.innerHTML=h;
}

/* ---------- wiring ---------- */
el.hand.addEventListener('click',function(e){var b=e.target.closest('.card');if(b)pickCard(+b.dataset.i)});
el.chips.addEventListener('click',function(e){
  var o=e.target.closest('[data-op]');if(o){pickOp(o.dataset.op);return}
  var p=e.target.closest('[data-par]');if(p)pickPar(p.dataset.par);
});
el.undo.addEventListener('click',undo);
el.clear.addEventListener('click',clearAll);
el.giveup.addEventListener('click',function(){endRound('giveup')});
el.rBtn.addEventListener('click',function(){(S.you>=GOAL||S.cpu>=GOAL)?resetMatch():startRound()});
el.rulesBtn.addEventListener('click',function(){
  var open=el.rules.hidden;el.rules.hidden=!open;el.rulesBtn.setAttribute('aria-expanded',String(open));
});
el.histBtn.addEventListener('click',function(){
  var open=el.history.hidden;el.history.hidden=!open;el.histBtn.setAttribute('aria-expanded',String(open));
  if(open)renderHist();
});
var clearTimer=0;
el.history.addEventListener('click',function(e){
  var b=e.target.closest('#hClear');if(!b)return;
  if(b.dataset.armed){clearTimeout(clearTimer);hist=[];saveHist();updateHistBtn();renderHist();return}
  b.dataset.armed='1';b.textContent='Tap again to clear all';
  clearTimer=setTimeout(function(){if(b.isConnected){delete b.dataset.armed;b.textContent='Clear history'}},2500);
});
el.diff.addEventListener('change',function(){
  S.diff=el.diff.value;try{localStorage.setItem('t24-73-211-diff',S.diff)}catch(e){}
});
var armTimer=0;
el.newBtn.addEventListener('click',function(){
  if(S.you+S.cpu===0&&S.phase!=='over'){resetMatch();return}
  if(el.newBtn.dataset.armed){clearTimeout(armTimer);delete el.newBtn.dataset.armed;el.newBtn.textContent='New match';resetMatch();return}
  el.newBtn.dataset.armed='1';el.newBtn.textContent='Tap again to reset';
  armTimer=setTimeout(function(){delete el.newBtn.dataset.armed;el.newBtn.textContent='New match'},2500);
});
document.addEventListener('keydown',function(e){
  if(e.metaKey||e.ctrlKey||e.altKey)return;
  var tag=e.target.tagName||'';
  if(tag==='SELECT'||tag==='INPUT')return;
  if(!el.result.hidden){if(e.key==='Enter'&&tag!=='BUTTON'){e.preventDefault();el.rBtn.click()}return}
  if(!canPlay())return;
  var k=e.key;
  if(/^[1-9]$/.test(k)){var i=+k-1;if(i<S.puzzle.n){pickCard(i);e.preventDefault()}return}
  var map={'+':'+','-':'−','−':'−','*':'×','x':'×','X':'×','/':'÷','÷':'÷'};
  if(map[k]){pickOp(map[k]);e.preventDefault();return}
  if(k==='('||k===')'){pickPar(k);return}
  if(k==='Backspace'){undo();e.preventDefault();return}
  if(k==='Escape')clearAll();
});

renderScore();
updateHistBtn();
startRound();
})();
